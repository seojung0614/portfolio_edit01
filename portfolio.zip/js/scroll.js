$(window).on('scroll',function(e){
    let scrTop = $(document).scrollTop();
    scroll(scrTop);
    scroll2(scrTop);
    scroll3(scrTop);
    headerscroll(scrTop);    
})    
/* HEADER SCROLL */
function headerscroll(i){
    if(i>0){
        $('.header').addClass('active');
    }else{
        $('.header').removeClass('active');
    }
}
/* ABOUT SCROLL */
function scroll(e){
        if(e >= 111){
            $('.about h2,.about .img_box,.about h3,.about p,.about .about_bottom p,.about .img_box02 img,.about .container').addClass('active')                ;
            }else{
            $('.about h2,.about .img_box,.about h3,.about p,.about .about_bottom p,.about .img_box02 img,.about .container').removeClass('active');             
        };
    }
/* SKILLS SCROLL */
function scroll2(e){
    if(e >=555){
        $('.skill_img,.skill_img .effect,.skills h2,.skills').addClass('active');
    /* 스킬아이콘 원상복구 */
    $('#html').attr('src','./images/skills_bubble_html.gif');
    $('#html_txt').text('HTML');
    $('#css').attr('src','./images/skills_bubble_css.gif');
    $('#css_txt').text('CSS');
    $('#js').attr('src','./images/skills_bubble_js.gif');
    $('#js_txt').text('JavaScript');
    $('#jq').attr('src','./images/skills_bubble_jq.gif');
    $('#jq_txt').text('jQuery');
    $('#ps').attr('src','./images/skills_bubble_ps.gif');
    $('#ps_txt').text('Photoshop');
    $('#ai').attr('src','./images/skills_bubble_illu.gif');
    $('#ai_txt').text('Illustrator');
    $('#ae').attr('src','./images/skills_bubble_ae.gif');
    $('#ae_txt').text('AfterEffect');
    $('#pr').attr('src','./images/skills_bubble_pr.gif');
    $('#pr_txt').text('PremierePro');
    $('#ms').attr('src','./images/skills_bubble_ms.gif');
    $('#ms_txt').text('Office');
    }
    else{
        $('.skill_img,.skill_img .effect,.skills h2').removeClass('active');
        
    };
} 
/* PORTFOLIO SCROLL */
function scroll3(e){
    if(e >= 1022){
        $('.slider_container,.port_content h2,.port_content>p').addClass('active');
        rightSliderdown(300);    
    }else{
        $('.slider_container,.port_content h2,.port_content>p').removeClass('active');
        rightSliderup(300);
        $('.slider_container>.slide').removeAttr('style')
        positionLeft = 0;
    }        
}
function rightSliderup(){
    $('.slider_right_container').slideUp(300);
}
function rightSliderdown(){
    $('.slider_right_container').slideDown(300);
}
$('.slider').on('click',function(){
    let slideIndex = $(this).last()
    /* console.log(slideIndex) */
    
})
 