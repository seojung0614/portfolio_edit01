$(function(){    
    console.log('방문해주셔서 감사합니다.')
    console.log('좋은 소식 기다리겠습니다.')
    let positionLeft = 0
    let txtLeft = 0;
    let cnt = 0
    let typingBool = false; 
    let typingIdx=0; 
    let liIndex = 0;
    let liLength = $(".typing_txt>ul>li").length;
    let typingTxt = $(".typing_txt>ul>li").eq(liIndex).text(); 
    typingTxt=typingTxt.split("");
    if(typingBool==false){
    typingBool=true; 
    let tyInt = setInterval(typing,100);    
    }      
    function typing(){ 
    $(".typing ul li").removeClass("on");
    $(".typing ul li").eq(liIndex).addClass("on");   
    if(typingIdx<typingTxt.length){
    $(".typing ul li").eq(liIndex).append(typingTxt[typingIdx]);
    typingIdx++; 
    }else{
    if(liIndex<liLength-1){     
       liIndex++;      
       typingIdx=0;
       typingBool = false; 
       typingTxt = $(".typing_txt>ul>li").eq(liIndex).text();        
       setTimeout(function(){           
       tyInt = setInterval(typing,100);
       },1000);
       } else if(liIndex==liLength-1){                   
       clearInterval(tyInt);
       }
     } 
    } 
    function goTop(){
        $(document).scrollTop(0);
        } 
    $('#btn_nav').on('click',function(){
        $('.nav').addClass('active');        
    })       
    $('#btn_nav').on('mousedown',function(){
        $(this).children('img').attr('src','./images/ham_after.png')
    })
    $('#btn_nav').on('mouseup',function(){
        $(this).children('img').attr('src','./images/ham_before.png')
    })
    $(".nav").mouseup(function (e){        
        if($(".nav").has(e.target).length === 0){
            $(".nav").removeClass("active");
        }        
    }); 
    $('#btn_nav_clo').on('click',function(){
        $('.nav').removeClass('active');        
    })    
    $('.btn_click').on('click',function(){
        $('.loading').addClass('active');    
    /* 인트로 파트  첫화면 golive클릭후에 동작함*/
        setInterval(function(timer){
            $('.mulcong_img_box').addClass('active');
            clearInterval(timer);
        },500)    
        setInterval(function(timer){
            $('.text_box').addClass('active');
            $('.text_box img').addClass('active');
            $('.intro .container h1').addClass('active');
            clearInterval(timer)
        },1000)
        goTop();
    })   
    /* SCROLL */
    //다음버튼슬라이드
    /* 포폴 추가시 ul의 너비만 조절해주면 됨 */
    $('#btn_next').on('click',function(){        
        let slideLength = $('.slide li').length -1;
        if(cnt < slideLength){
            cnt++;
            positionLeft -= 360;
            txtLeft -= 480;
            $('#slide').animate({
                left : positionLeft + 'px'
            },200);
            $('.slide_right').animate({
                left : txtLeft + 'px'
            },200);            
        }
    });
    // 이전버튼슬라이드
    $('#btn_prev').on('click',function(){
        if(positionLeft < 0){
            cnt -= 1
            positionLeft += 360;
            txtLeft += 480;
            $('#slide').animate({
                left : positionLeft + 'px'
            },200);
            $('.slide_right').animate({
                left : txtLeft + 'px'
            },200);            
        }
    });
    txtTyping()
    function txtTyping(){
        let foot = $('.foot_tit');        
        let txtStrong = $('.foot_tit').text().trim();
        /* console.log(txtStrong) */
        foot.text('')        
        let subSting = '';
        let indexNum = 0;
        let rotateString = setInterval(function(){            
            if(indexNum < txtStrong.length){
            subSting = subSting + txtStrong[indexNum];            
            foot.text(subSting)            
            indexNum++;
            /* console.log(subSting) */
        }else{
            subSting = '';            
            indexNum = 0
        }   
        },150)   
    }
    /* SKILLS ICON */   
    $('.effect li').on('click',function(){        
    let Img = $(this).children('div').children('img')
    let Txt = $(this).children('p')
    let thisIndex = $(this).index();
    if(thisIndex == 0){
    Img.attr('src','./images/skills_html.png');
    Txt.text('웹표준 기반으로 웹문서를 작성할수 있습니다.');
    }
    else if(thisIndex == 1){
       Img.attr('src','./images/skills_css.png');
       Txt.text('트렌드를 반영한 레이아웃 구현을 할수 있습니다.');
    }
    else if(thisIndex == 2){
       Img.attr('src','./images/skills_js.png');
       Txt.text('각종 이벤트를 작성 할 수 있기 위해서 열심히 공부중입니다.');
    }
    else if(thisIndex == 3){
       Img.attr('src','./images/skills_jq.png');
       Txt.text('각종 메서드,플러그인 조합으로 반응형 웹을 구현할수있습니다.');
    }
    else if(thisIndex== 4){
       Img.attr('src','./images/skills_ps.png');
       Txt.text('디자인제작,보정 등 상세 페이지 제작이 가능합니다 ');
    }
    else if(thisIndex == 5){
       Img.attr('src','./images/skills_ai.png');
       Txt.text('icon / CI /BI/ 캐릭터 디자인 제작이 가능합니다.');
    }    
    else if(thisIndex == 6){
       Img.attr('src','./images/skills_ae.png');
       Txt.text('aftereffct를 이용한 동적인 효과를 만들수 있습니다.');
    }    
    else if(thisIndex == 7){
       Img.attr('src','./images/skills_pr.png');
       Txt.text('기초적인 영상 편집을 할 수 있습니다.');
    }    
    else if(thisIndex == 8){
       Img.attr('src','./images/skills_ms.png');
       Txt.text('기본적인 파워포인트,엑셀 등 문서작업이 가능합니다.');
    }    
})
})




